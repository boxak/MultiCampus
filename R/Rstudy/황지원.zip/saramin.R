getwd()
setwd("C:/boxak/Rstudy/function")
source("crawler.R",encoding = "UTF-8")

url <- "http://www.saramin.co.kr/zf_user/search?search_area=main&search_done=y&search_optional_item=n&searchType=default_mysearch&searchword=Java"
selector <- "li.swiper-slide.add-filter.swiper-slide-active > input"
tech_name <- page.getAttr(url,css = selector)
